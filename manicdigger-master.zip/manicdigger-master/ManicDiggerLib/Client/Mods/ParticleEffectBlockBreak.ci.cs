﻿public class ModDrawParticleEffectBlockBreak : ClientMod
{
    public override void OnNewFrameDraw3d(Game game, float deltaTime)
    {
    }
    public void StartParticleEffect(float x, float y, float z)
    {
    }
}
