﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ManicDigger.Server
{
	/// <summary>
	/// TODO: Implement monster movement
	/// </summary>
	class ServerSystemMonsterWalk : ServerSystem
	{
		
	}
}
